# How to contribute

Contributions to this module are welcome. We welcome bug fixes and new features and capabilities that may be of general interest.

## Getting Started

* Ensure that there is a Jira ticket to track your issue.
* If you have permission to create a branch create a branch on the repository. Otherwise, in the case of some central CCOE repos, fork the repository first.

## Making Changes

* Create a topic branch from where you want to base your work.
  * This is usually the master branch.
  * Create a topic branch using the following format case sensitive:
    `git checkout -b CC-1234/description_of_my_issue_in_snake_case`.
* Make commits of logical units. If necessary, squash your commits before raising a merge request.
* We require commit messages to follow the [7 rules of a commit message](https://chris.beams.io/posts/git-commit/):

```
(CC-1234) Summarise in 50 characters or less

More detailed explanatory text, if necessary. Wrap it to about 72
characters or so. In some contexts, the first line is treated as the
subject of the commit and the rest of the text as the body. The
blank line separating the summary from the body is critical (unless
you omit the body entirely); various tools like log, shortlog
and rebase can get confused if you run the two together.

Explain the problem that this commit is solving. Focus on why you
are making this change as opposed to how (the code explains that).
Are there side effects or other unintuitive consequences of this
change? Here is the place to explain them.
```

* Raise a merge request and assign to an appropriate code reviewer. Explain in a comment in the merge request if the code has not been fully tested (more below).
* The reviewer should review the code, and to approve, tick the "thumbs up" button and then assign back to the author to merge - unless the author lacks permission to merge.

## Testing your changes

Prior to raising a merge request we expect changes to have been tested.

Depending on the nature of the change we trust the author to:
* Test their code
* Be transparent about how they tested their code and acknowledge anything that has not been tested properly.

In some circumstances, it is not necessary to test the code. For example, the change might involve only changes to documentation or minor style changes. This is fine, as long as the author of the merge request is transparent and explains the change is not tested and gives the reason why it was not tested. It then becomes the job of the code reviewer to decide if further testing is required.

Many changes to capabilities require interaction of a number of components including:
* Puppet Control
* Jenkins puppet module
* Other puppet modules
* Cloudformation
* Scripts

Our testing strategy is as follows:
* Wherever possible, test your changes by adding appropriate Rspec tests.
* To test manually:
  * Create a branch on each affected component using `git checkout -b CC-1234/description_of_my_issue_in_snake_case`.
  * If you need a branch on more than one component be sure to use exactly the same branch name on each component.
  * If dependencies mentioned in `Puppetfile` in the Puppet Control repo are changing, create a branch off Puppet Control and then off each of the Puppet modules that are changing, and then update `Puppetfile` to point to those branches. Be sure to commit this in a single commit to Puppet Control with a message like `temp puppetfile commit`. The reason for this is that you will need to eventually revert this commit again before the changes can be merged into the Puppet Control master branch.
  * Now build a Jenkins using the `Create_Jenkins_Stack` job. Specify any branches off Puppet Control, Cloudformation and Scripts here. If Puppet Control has a `Puppetfile` pointing to more branches off depedeny Puppet modules, these will exist in the Jenkins you create in this step.
  * From the test Jenkins you created, you can now test your new capability.
  * Remember to delete these temporary Jenkins stacks as they are expensive to run!
