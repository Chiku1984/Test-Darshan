require 'spec_helper'
require 'nokogiri'
require 'json'

job_name    = 'Create_Atlassian_Application_Stack'
cf_template = 'Confluence.json'
job_template_dir = 'jenkins_config/jobs'
no_start_stop_hour = false
# Mock calls to AWS.
def get_from_aws(input)
  case input
  when 'AMI'
    output = ['ami-abcd1234 AMP-RHEL7-SOE-v1.11a']
  when 'RDS_Endpoint'
    output = ['abcdefghijkl.mnopqrstuvwx.ap-southeast-2.rds.amazonaws.com',
              'mnopqrstuvwx.abcdefghijkl.ap-southeast-2.rds.amazonaws.com']
  when 'Jenkins_Shared_SG'
    output = 'Jenkins-Dependencies-JenkinsSharedSG-ABCDEF123456 sg-abcd1234'
  when 'Bastion_SGID'
    output = 'Bastion-Dependencies-Bastion_SGID-ABCDEF123456 sg-abcd1234'
  when 'Restore_Snapshot_Id'
    output = ['', # It will be blank unless 'Restore from Snapshot' is True.
              'snap-abcd1234 some human readable description',
              'snap-efgh5678 some human readable description']
  when 'restore_snapshot_id'
    output = [0, 1] # FIXME. This is a guess! It represents return codes from aws copy-snapshot.
                    # This code is informational only - it will not be executed.
  when 'vpc_cidr_block'
    output = '10.0.0.0/8' # FIXME. This is also a guess.
  end
  output
end

config_hash = {
  'cloudformation_git_url' => 'git@myexample.git.com:FOO/cloudformation.git',
  'cloudformation_git_ref' => 'master',
  'scripts_git_url'        => 'git@myexample.git.com:FOO/scripts.git',
  'scripts_git_ref'        => 'master',
}

jenkins_global_vars = {
  'AWS_AMP_TENANT'         => 'CON',
  'AWS_S3_BUCKET_NAME'     => ['amp-confluence-np', 'amp-confluence-pilot', 'amp-confluence'],
  'AWS_COST_CENTER'        => 'TW033',
  'AWS_ENVIRONMENT'        => ['UAT', 'DEV', 'PRD'],
  'AWS_CREDSTASH_KEY_GUID' => ['9d225134-3b71-4890-9a52-d1d819a31339',
                               'e5d21d4f-1fd8-496b-afad-413fc40e47a9',
                               '98269d51-0762-415c-96a3-e8e40ce58ac5'],
  'AWS_CLOUD2_SOE_SUPPORT_TAG' => 'Infosys',
  'AWS_MIDTIER_SUBNET_IDS' => ['subnet-d00146b5,subnet-00bdd077',
                               'subnet-deed8aa9,subnet-57017832',
                               'subnet-db0146be,subnet-0abdd07d'],
  'AWS_VPC_ID'             => ['vpc-5027bb35', 'vpc-a9e575cc', 'vpc-5f27bb3a'],
  'AWS_CCOE_IN_PRIVDMZ_CIDR' => ['192.168.35.0/24', '192.168.75.0/24', '192.168.3.0/24'],
  'AWS_SNS_TOPIC_ARN'      =>   'arn:aws:sns:ap-southeast-2:821146817103:AMPalert',
  'ATLASSIAN_START_HOUR'   => 'DoNotStart',
  'ATLASSIAN_STOP_HOUR'    => 'DoNotStop',
}

choice_parameters = {
  'Application'            => ['confluence', 'jira'],
  'Instance_Type'          => ['c4.xlarge', 'c4.large', 't2.medium', 't2.micro'],
  'RDS_Endpoint'           => get_from_aws('RDS_Endpoint'),
  'Jenkins_Shared_SG'      => get_from_aws('Jenkins_Shared_SG'),
  'AMI'                    => get_from_aws('AMI'),
  'Bastion_SGID'           => get_from_aws('Bastion_SGID'),
  'Ebs_Size'               => ['50', '100', '150', '200', '250'],
  'Restore_From_Snapshot'  => ['No', 'Yes'],  # FIXME. This should be a boolean parameter.
}

boolean_parameters = {
  'Use_Bastion_Host'       => ['false', 'true'],
}

cascade_choice_parameters = {
  'Restore_Snapshot_Id'    => get_from_aws('Restore_Snapshot_Id'),
}

password_parameters = {}

string_parameters = {
  'Cloudformation_Git_URL' => config_hash['cloudformation_git_url'],
  'Cloudformation_Git_Ref' => config_hash['cloudformation_git_ref'],
  'Scripts_Git_URL'        => config_hash['scripts_git_url'],
  'Scripts_Git_Ref'        => config_hash['scripts_git_ref'],
}

shell_variables = {
  'my_snapshot_id'         => choice_parameters['Restore_From_Snapshot'] == 'Yes' ? cascade_choice_parameters['Restore_Snapshot_Id'].split[0] : '',
  'restore_snapshot_id'    => choice_parameters['Restore_From_Snapshot'] == 'Yes' ? get_from_aws('restore_snapshot_id') : '',
  'ami'                    => choice_parameters['AMI'][0].split[0],
  'bastion_sgid'           => choice_parameters['Bastion_SGID'].split[1],
  'jenkins_shared_sg'      => choice_parameters['Jenkins_Shared_SG'].split[1],
  'vpc_cidr_block'         => get_from_aws('vpc_cidr_block'),
  'owner'                  => 'Alex Harvey',
}

date_time = Time.new.strftime('%Y%m%d%H%M')

jenkins_special_variables = {
  'BUILD_NUMBER'           => '1',
}

env_inject_variables = {
  'STACK_NAME'             => "#{jenkins_global_vars['AWS_ENVIRONMENT'][0]}-#{choice_parameters['Application'][0]}-#{date_time}-#{jenkins_special_variables['BUILD_NUMBER']}",
}

variables_hash = jenkins_global_vars.merge(choice_parameters).merge(cascade_choice_parameters).merge(password_parameters).merge(boolean_parameters).merge(string_parameters).merge(shell_variables).merge(jenkins_special_variables).merge(env_inject_variables)

describe 'jenkins::jobs', :type => 'define' do

  let(:pre_condition) {
    [
      "jenkins::config_reload { 'job':
        security_enabled => true,
        ssl_enabled => true,
        ssl_port => 8443,
        user_name => 'jenkins',
      }",
    ]
  }
  let(:title) { 'Create_Atlassian_Application_Stack' }
  let(:params) do
    {
      'config' => config_hash,
      'job_template_dir' => 'jenkins_config/jobs',
    }
  end

#  Uncomment after CC-1821.
#  it 'variables.json should also match Jira CF template' do
#    json_snippet = catalogue.resource('file', '/tmp/Create_Atlassian_Application_Stack.xml').send(:parameters)[:content].
#      match(/variables\.json(.*?)EOF/m)[1]
#    modified_json_snippet = interpolate_variables(json_snippet, variables_hash)
#    validate_snippet_parameters(modified_json_snippet, 'cloudformation/Jira.json')
#  end
end

variables_hash = jenkins_global_vars.merge(choice_parameters).merge(cascade_choice_parameters).merge(password_parameters).merge(boolean_parameters).merge(string_parameters).merge(shell_variables).merge(jenkins_special_variables).merge(env_inject_variables)

describe 'jenkins::jobs', :type => 'define' do

  let(:pre_condition) {
    [
      "jenkins::config_reload { 'job':
        security_enabled => true,
        ssl_enabled => true,
        ssl_port => 8443,
        user_name => 'jenkins',
      }",
    ]
  }
  let(:title) { job_name }
  let(:params) do
    {
      'config' => config_hash,
      'job_template_dir' => job_template_dir,
    }
  end

  it {
    is_expected.to contain_file("/tmp/#{job_name}.xml")
  }

  it 'should have valid XML' do
    content = catalogue.resource('file', "/tmp/#{job_name}.xml").send(:parameters)[:content]
    expect(Nokogiri::XML(content).errors.empty?).to be true
  end

  ['variables.json', 'tags.json'].each do |json_file|
    it "XML should contain a #{json_file} snippet that is valid JSON" do
      json_snippet = catalogue.resource('file', "/tmp/#{job_name}.xml").send(:parameters)[:content].
        match(/#{json_file}(.*?)EOF/m)[1]
      expect { JSON.parse(json_snippet) }.to_not raise_error
    end

    it "#{json_file} snippet should contain keys sorted alphabetically" do
      json_snippet = catalogue.resource('file', "/tmp/#{job_name}.xml").send(:parameters)[:content].match(/variables\.json(.*?)EOF/m)[1]
      snippet_parameters_are_alphabetically_ordered(json_snippet)
    end

    it "parameters in #{json_file} should not be blank" do
      json_snippet = catalogue.resource('file', "/tmp/#{job_name}.xml").send(:parameters)[:content].
        match(/#{json_file}(.*?)EOF/m)[1]
      modified_json_snippet = interpolate_variables(json_snippet, variables_hash)
      snippet_parameters_have_values(modified_json_snippet, ['RestoreSnapshotId'])
    end
  end

#  Uncomment after CC-1821.
#  it 'variables.json should match CF template' do
#    json_snippet = catalogue.resource('file', "/tmp/#{job_name}.xml").send(:parameters)[:content].
#      match(/variables\.json(.*?)EOF/m)[1]
#    modified_json_snippet = interpolate_variables(json_snippet, variables_hash)
#    validate_snippet_parameters(modified_json_snippet, "cloudformation/#{cf_template}")
#  end

  unless no_start_stop_hour
    it 'tags.json must contain StartHour and StopHour tags' do
      json_snippet = catalogue.resource('file', "/tmp/#{job_name}.xml").send(:parameters)[:content].
        match(/tags\.json(.*?)EOF/m)[1]
      expect(json_snippet).to match /"Key": "StartHour"/
      expect(json_snippet).to match /"Key": "StopHour"/
    end
  end

  it 'keys in variables_hash and config_hash should be mentioned in the real template' do
    variables_hash.keys.each do |key|
      if %x{grep #{key} templates/jobs/#{job_name}.xml.erb} == ''
        puts "\n(#{key} not found in templates/jobs/#{job_name}.xml.erb.)"
      end
      expect(%x{grep #{key} templates/jobs/#{job_name}.xml.erb}).to_not eq ''
    end
    config_hash.keys.each do |key|
      if %x{grep @config.*#{key} templates/jobs/#{job_name}.xml.erb} == ''
        puts "\n(@config.*#{key} not found in templates/jobs/#{job_name}.xml.erb.)"
      end
      expect(%x{grep @config.*#{key} templates/jobs/#{job_name}.xml.erb}).to_not eq ''
    end
  end

  # Check that embedded Ruby generates expected content.

  [

"        <submoduleCfg class=\"list\"/>
        <extensions>
          <hudson.plugins.git.extensions.impl.RelativeTargetDirectory>
            <relativeTargetDir>cloudformation</relativeTargetDir>
          </hudson.plugins.git.extensions.impl.RelativeTargetDirectory>
        </extensions>
",

"# Get the owner by searching the first line of the current build log file.
# Line contains a control character ^[[0m which sets text colour.

owner=$(head -1 /var/lib/jenkins/jobs/${JOB_NAME}/builds/${BUILD_NUMBER}/log |
  sed -e 's/.*Started by user.*\\x1b\\[0m\\(.*\\)/\\1/')
",

"aws cloudformation create-stack --stack-name ${STACK_NAME} \\
  --template-body file://cloudformation/#{cf_template} \\
  --parameters file://variables.json \\
  --tags file://tags.json \\
  --capabilities CAPABILITY_IAM \\
  --disable-rollback
",

  ].map{|k| k.split("\n")}.each do |text|

    it {
      verify_contents(catalogue, "/tmp/#{job_name}.xml", text)
    }
  end

  it {
    is_expected.to contain_exec("Create job - '#{job_name}'").with({
      'command' => "java -jar jenkins-cli.jar -s http://localhost:8080/ -noCertificateCheck create-job #{job_name} < /tmp/#{job_name}.xml",
      'creates' => "/var/lib/jenkins/jobs/#{job_name}/config.xml",
    })
  }

  it {
    is_expected.to contain_exec("Update job - '#{job_name}'").with({
      'command' => "java -jar jenkins-cli.jar -s http://localhost:8080/ -noCertificateCheck update-job #{job_name} < /tmp/#{job_name}.xml",
      'unless'  => "diff /tmp/#{job_name}.xml /var/lib/jenkins/jobs/#{job_name}/config.xml",
    })
  }

  it {
    File.write(
      "catalogs/jobs/#{job_name}.json",
      PSON.pretty_generate(catalogue)
    )
  }
end
