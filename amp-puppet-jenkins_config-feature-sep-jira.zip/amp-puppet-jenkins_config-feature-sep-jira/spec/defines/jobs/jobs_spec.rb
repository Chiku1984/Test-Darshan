# THIS FILE IS CENTRALLY MANAGED BY update_rspec.rb!
# DO NOT EDIT IT HERE!

require 'spec_helper'
require 'nokogiri'
require 'json'

def looks_like_array(code)
  code =~ /^@config\[ ?'.*' ?\](?:\.each|\.join|\[.*\])/
end

def looks_like_scalar(code)
  code =~ /^@config\[ ?'.*' ?\]/
end

def capture_name(code)
  begin
    code.match(/^@config\[ ?'(.*)' ?\]/).captures[0]
  rescue
    puts "could not extract a key name from #{code}"
  end
end

def extract_code(line)
  line.
    sub(/.*?<%[=-]? /, '').
    sub(/^if /,       '').
    sub(/ %>.*/,      '')
end

def guess_config_vars(file)
  config = Hash.new
  File.readlines(file).each do |line|
    if line.match(/@config/)
      code = extract_code(line)
      key  = capture_name(code)
      if looks_like_array(code)
        config[key] = ['foo', 'bar']
      elsif looks_like_scalar(code)
        config[key] = 'foobar'
      else
        puts "Found @config in #{file} but did not guess the key!"
      end
    end
  end
  config
end

def guess_template_dir
  remote = %x{git remote -v}.split[1]
  if remote =~ /jenkins_config/
    'jenkins_config/jobs'
  else
    'jenkins/jobs'
  end
end

jobs_from_detailed = Dir.glob('spec/defines/jobs/detailed/*_spec.rb').map do |f|
  f.match(/spec\/defines\/jobs\/detailed\/(.*)_spec\.rb/)[1]
end

jobs_from_templates = Dir.glob('templates/jobs/*.xml.erb').map do |f|
  f.match(/templates\/jobs\/(.*)\.xml\.erb/)[1]
end

unknown_jobs = jobs_from_templates - jobs_from_detailed

describe 'jenkins::jobs', :type => 'define' do

  unknown_jobs.each do |job|

    config_hash  = guess_config_vars("templates/jobs/#{job}.xml.erb")
    template_dir = guess_template_dir

    context job do
      let(:pre_condition) {
        [
          "jenkins::config_reload { 'job':
            security_enabled => true,
            ssl_enabled => true,
            ssl_port => 8443,
            user_name => 'jenkins',
          }",
        ]
      }
      let(:title) { job }
      let(:params) do
        {
          'config' => config_hash,
          'job_template_dir' => template_dir,
        }
      end

      it "#{job} should exist and have valid XML" do
        is_expected.to contain_file("/tmp/#{job}.xml")
        content = catalogue.resource('file', "/tmp/#{job}.xml").send(:parameters)[:content]
        result = Nokogiri::XML(content).errors.empty?
        if ! result
          puts "    #{Nokogiri::XML(content).errors}"
        end
        File.open("catalogs/jobs/xml/#{job}.xml", 'w') {|g| g.write(content)}
        expect(result).to be true
      end

      it "#{job} should have a valid JSON snippet or no snippet" do
        content = catalogue.resource('file', "/tmp/#{job}.xml").send(:parameters)[:content]
        if content =~ /variables\.json(.*)EOF/
          json_snippet = content.match(/variables\.json(.*)EOF/m)[1]
          expect { JSON.parse(json_snippet) }.to_not raise_error
        end
      end

      it "#{job} should have valid Bash Shell scripts or no scripts" do
        content = catalogue.resource('file', "/tmp/#{job}.xml").send(:parameters)[:content]
        shell_scripts = Nokogiri::XML(content).xpath('/project/builders/hudson.tasks.Shell/command').map(&:text)
        shell_scripts.each_with_index do |s,i|
          [['&lt;', '<'], ['&gt;', '>'], ['&amp;', '&'], ['&quot;', '"'], ['&apos;', "'"]].each do |k,v|
            s.gsub!(/#{k}/, v)
          end
          f = "catalogs/jobs/bash/#{job}_#{i}.sh"
          File.open(f, 'w') {|g| g.write(s)}
          result = system("bash -n #{f} > /dev/null 2>&1")
          if ! result
            puts "      Job #{job} has a Bash script #{job}_#{i}.sh with syntax errors"
          end
          expect(result).to be true
        end
      end

      Dir.glob("catalogs/jobs/bash/#{job}_*.sh").each do |f|
        test_file = "shunit2/#{File.basename(f)}"
        if File.exist?(test_file)
          it "shUnit2 tests in #{test_file} should pass" do
            puts "      Running shUnit2 tests in #{test_file}:\n\n"
            puts %x{bash #{test_file}}.gsub(/^/m, '      ')
            expect($?.exitstatus).to eq 0
          end
        end
      end

      it "#{job} should write out a compiled catalog" do
        is_expected.to compile.with_all_deps
        File.write(
          "catalogs/jobs/#{job}.json",
          PSON.pretty_generate(catalogue)
        )
      end
    end
  end
end
