# THIS FILE IS CENTRALLY MANAGED BY update_rspec.rb!
# DO NOT EDIT IT HERE!

require 'spec_helper'

describe 'bad characters in XML file' do
  Dir.glob('templates/jobs/*.xml.erb').each do |file|
    content = File.read(file)
    [
      '&quot;',  #  use "
      '&apos;',  #  use '
      '&#13;',   #  line feed - use newline
      '&#xd;',   #  carriage return - use newline
    ]
    .each do |bad_character|

      it "#{bad_character} in #{file}" do
        expect(content).to_not match /#{bad_character}/
      end
    end

    it "tab character in #{file}" do
      expect(content).to_not match /\t/
    end
  end
end
