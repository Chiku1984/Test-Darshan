# THIS FILE IS CENTRALLY MANAGED BY update_rspec.rb!
# DO NOT EDIT IT HERE!

require 'puppetlabs_spec_helper/module_spec_helper'

def verify_contents(subject, title, expected_lines)
  content = subject.resource('file', title).send(:parameters)[:content].gsub(/\r/, '')
  expect(content.split("\n") & expected_lines).to match_array expected_lines.uniq
end

def validate_snippet_parameters(json_snippet, cf_template)
  cfn_template_data = JSON.parse(File.read(cf_template))

  variables_json_parameter_list = []
  JSON.parse(json_snippet).each do |el|
    variables_json_parameter_list << el['ParameterKey']
  end
  variables_json_parameter_list.sort!

  cfn_template_parameter_list = cfn_template_data['Parameters'].keys.sort

  expect(variables_json_parameter_list).to match_array cfn_template_parameter_list
end

def interpolate_variables(json_snippet, variables_hash)
  variables_hash.keys.each do |key|
    val = variables_hash[key]

    # An array is allowed to indicate to the reader the range of values expected.
    # For testing purposes, however, we always use the first element. This allows
    # us to avoid a complex programming problem (testing all combinations of all
    # possible input values) and allows us still to feel quite confident in the
    # results.

    if val.is_a?(Array)
      val = val[0]
    end
    if val.nil?
      val = ''
    end

    json_snippet.gsub!(/\${#{key}}/, val)
    json_snippet.gsub!(/\$#{key}/,   val)
  end

  # Any variables that remain uninterpolated get blanked so that the test fails.
  json_snippet.gsub!(/\${[^}]*}/,    '')
  json_snippet.gsub!(/\$[a-zA-Z_]+/, '')

  json_snippet
end

def snippet_parameters_have_values(json_snippet, exceptions = [])
  JSON.parse(json_snippet).each do |el|

    # variables.json will contain 'ParameterKey' / 'ParameterValue'
    # whereas tags.json will contain 'Key' / 'Value'

    # 'key_key' means 'key containing the key name'...

    key_key = el.has_key?('ParameterKey') ? 'ParameterKey' : 'Key'
    value_key = el.has_key?('ParameterValue') ? 'ParameterValue' : 'Value'

    unless exceptions.include?(el[key_key])
      if el[value_key] == ''
        puts "\n(#{el[key_key]} is an empty string.)"
      end
      expect(el[value_key]).to_not eq ''
    end
  end
end

def snippet_parameters_match_cfn_allowed_pattern_and_values(json_snippet, cf_template)
  cfn_template_data = JSON.parse(File.read(cf_template))

  JSON.parse(json_snippet).each do |el|
    if cfn_template_data['Parameters'][el['ParameterKey']].has_key?('AllowedPattern')
      regexp = cfn_template_data['Parameters'][el['ParameterKey']]['AllowedPattern'].gsub(/\\\\/, '\\')
      if el['ParameterValue'] !~ /#{regexp}/
        puts "\n(#{el['ParameterValue']} does not match its allowed pattern pattern #{regexp}.)"
      end
      expect(el['ParameterValue']).to match regexp
    end

    if cfn_template_data['Parameters'][el['ParameterKey']].has_key?('AllowedValues')
      allowed_values = cfn_template_data['Parameters'][el['ParameterKey']]['AllowedValues']
      unless allowed_values.include?(el['ParameterValue'])
        puts "\n(#{el['ParameterValue']} is not included in the AllowedValues for #{el['ParameterKey']}.)"
      end
      expect(allowed_values).to include el['ParameterValue']
    end
  end
end

def snippet_parameters_for_aws_types_are_sane(json_snippet, cf_template)
  cfn_template_data = JSON.parse(File.read(cf_template))

  JSON.parse(json_snippet).each do |el|
    if cfn_template_data['Parameters'][el['ParameterKey']]['Type'] == 'AWS::EC2::SecurityGroup::Id'
      regexp = '^sg-[a-f0-9]{8}$'
      if el['ParameterValue'] !~ /#{regexp}/
        puts "\n(#{el['ParameterValue']} does not look like a valid security group.)"
      end
      expect(el['ParameterValue']).to match regexp
    end

    if cfn_template_data['Parameters'][el['ParameterKey']]['Type'] == 'AWS::EC2::Image::Id'
      regexp = '^ami-[a-f0-9]{8}$'
      if el['ParameterValue'] !~ /#{regexp}/
        puts "\n(#{el['ParameterValue']} does not look like a valid AMI.)"
      end
      expect(el['ParameterValue']).to match regexp
    end

    if cfn_template_data['Parameters'][el['ParameterKey']]['Type'] == 'List<AWS::EC2::Subnet::Id>'
      regexp = '^subnet-[a-f0-9]{8},subnet-[a-f0-9]{8}$'
      if el['ParameterValue'] !~ /#{regexp}/
        puts "\n(#{el['ParameterValue']} does not look like a valid Subnet list.)"
      end
      expect(el['ParameterValue']).to match regexp
    end
  end
end

def snippet_parameters_are_alphabetically_ordered(json_snippet)
  keys = JSON.parse(json_snippet).map{|k| k['ParameterKey']}
  expect(keys).to eql keys.sort
end

RSpec.configure do |c|
  c.default_facts = {
    :ipaddress => '1.1.1.1',
  }
end
