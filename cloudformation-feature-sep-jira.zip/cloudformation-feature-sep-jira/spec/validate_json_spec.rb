require 'spec_helper'
require 'json'

# How these tests work.
#
# We specify a reference spec in the variable `spec`.
#
# Next, we loop through a list of Cloudformation JSON templates.
#
# The `#compare` method is then used to compare the actual JSON data with the reference spec.
#
# For every key in the template data, the method checks if a corresponding key exists in the
# reference spec. If it does, the key's value in the template data is compared against the
# key's value in the reference spec.  A passing test is created if the value is the same,
# and a failing test is created if it is different.
#
# The method also recursively tests nested Hashes and Arrays.
#
# Note that these tests do not guarantee that a Cloudformation template will contain any
# the keys in the reference spec; only that if it does contain any of these keys, then those
# keys will have the values specified.
#
# Here are some examples:
#
# 1) A template contains an AMI parameter:
#
#   "Parameters": {
#     "AMI": {
#       "Description":           "AMI to use for my cool new stack!!!!!",
#       "Type":                  "AWS::EC2::Image::Id",
#       "ConstraintDescription": "Must be a valid existing EC2 AMI formatted as \'ami-hhhhhhhh\'"
#     },
#
# But our reference spec contains:
#
#   "Parameters": {
#     "AMI": {
#       "Description":           "AMI to use",
#       "Type":                  "AWS::EC2::Image::Id",
#       "ConstraintDescription": "Must be a valid existing EC2 AMI formatted as \'ami-hhhhhhhh\'"
#     },
#
# This will result in a test failure because the value of the Description
# field is not 'AMI to use'.
#
# 2) A template contains an AMI parameter:
#
#   "Parameters": {
#     "AMI": {
#       "Description":           "AMI to use",
#       "Type":                  "AWS::EC2::Image::Id",
#       "ConstraintDescription": "Must be a valid existing EC2 AMI formatted as \'ami-hhhhhhhh\'",
#       "FooBar":                ["foo", "bar"]
#     },
#
# This will result in a false positive (i.e. test passing) despite an unexpected key FooBar
# existing. The logic cannot detect additional keys (nor should it).
#
# 3) A template contains an AMI parameter:
#
#   "Parameters": {
#     "AMI": {
#       "Description":           "AMI to use"
#     },
#
# Again the test will result in a false positive, because the logic allows for keys to be not
# present relative to the reference spec too.

spec = JSON.parse('{
  "AWSTemplateFormatVersion": "2010-09-09",
  "Parameters": {
    "AMI": {
      "Description":           "AMI to use",
      "Type":                  "AWS::EC2::Image::Id",
      "ConstraintDescription": "Must be a valid existing EC2 AMI formatted as \'ami-hhhhhhhh\'"
    },
    "BucketName": {
      "Description":           "Destination Bucket to use for artifacts",
      "Type":                  "String",
      "ConstraintDescription": "Bucket must exist",
      "AllowedPattern":        "^amp.+$"
    },
    "Environment": {
      "Description":           "Environment eg. DEV, PRD, SYS, etc",
      "Type":                  "String"
    },
    "InstanceType": {
      "Description":           "EC2 Instance type",
      "Type":                  "String",
      "ConstraintDescription": "Enter a valid instance type"
    },
    "Subnets": {
      "Description":           "Comma separated pair of Subnet IDs",
      "Type":                  "List<AWS::EC2::Subnet::Id>",
      "ConstraintDescription": "Must be a list of valid existing Subnet IDs expressed as as \'subnet-hhhhhhhh,subnet-hhhhhhhh\'"
    }
  },
  "Resources": {
    "AutoScalingGroup": {
      "Type": "AWS::AutoScaling::AutoScalingGroup",
      "Properties": {
        "LaunchConfigurationName": {"Ref": "LaunchConfiguration"},
        "HealthCheckGracePeriod":  1800
      }
    },
    "LaunchConfiguration": {
      "Type": "AWS::AutoScaling::LaunchConfiguration",
      "CreationPolicy": {"ResourceSignal": {"Count": "1", "Timeout": "PT10M"}},
      "Properties": {
        "InstanceType":       {"Ref": "InstanceType"},
        "IamInstanceProfile": {"Ref": "IamInstanceProfile"},
        "ImageId":            {"Ref": "AMI"},
        "KeyName":            {"Ref": "AWS::StackName"}
      }
    },
    "IamInstanceProfile": {
      "Type": "AWS::IAM::InstanceProfile",
      "Properties": {
        "Path": "/",
        "Roles": [{"Ref": "IamRole"}]
      }
    },
    "IamRole": {
      "Type": "AWS::IAM::Role",
      "Properties": {
        "Path": "/",
        "AssumeRolePolicyDocument": {
          "Version":   "2012-10-17",
          "Statement": [
            {
              "Effect":    "Allow",
              "Principal": {"Service": ["ec2.amazonaws.com"]},
              "Action":    ["sts:AssumeRole"]
            }
          ]
        }
      }
    },
    "LoadBalancer": {
      "Type": "AWS::ElasticLoadBalancing::LoadBalancer",
      "Properties": {
        "Scheme": "internal"
      }
    }
  }
}')

def compare(ref1, ref2)
  if ref1.is_a?(Hash)
    ref1.keys.each do |k|
      if ref2.has_key?(k)
        context k do
          if ref1[k].is_a?(String)
            it "'#{k}' should match spec" do
              expect(ref1[k]).to eq ref2[k]
            end
          elsif ref1[k].is_a?(Hash)
            compare(ref1[k], ref2[k])
          elsif ref1[k].is_a?(Array)
            ref1[k].each_index do |i|
              compare(ref1[k][i-1], ref2[k][i-1])
            end
          end
        end
      end
    end
  elsif ref1.is_a?(String)
    context ref1 do
      it "'#{ref1}' should match spec" do
        expect(ref1).to eq ref2
      end
    end
  elsif ref1.is_a?(Array)
    ref1.each_index do |i|
      compare(ref1[i-1], ref2[i-1])
    end
  end
end

Dir.glob('*.json').each do |file|
  describe("JSON in #{file}") do
    json = JSON.parse(File.read(file))
    compare(json, spec)

    begin
      json['Resources']['LaunchConfiguration']['Properties']['UserData']['Fn::Base64']['Fn::Join'][1]
      it 'should have a tag_own_volumes.py call' do
        expect(
          json['Resources']['LaunchConfiguration']['Properties']['UserData']['Fn::Base64']['Fn::Join'][1]
        ).to include(
          "[ -e /opt/aws/tag_own_volumes.py ] && /usr/bin/python /opt/aws/tag_own_volumes.py\n"
        )
      end
    rescue NoMethodError
      puts "Warning UserData not in #{file}"
    end
  end
end
