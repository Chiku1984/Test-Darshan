#!/usr/bin/env bash

# How to use this script.

# Step 1: (You can probably skip this step.) If necessary, export Facter variables.

#   export FACTER_puppet_control_git_url=git@gitlab.ccoe.ampaws.com.au:Confluence/puppet-control.git
#   export FACTER_puppet_control_git_ref=CC-1111/upgrade_jenkins

# Step 2: Run the script.

#   bash /opt/puppet/deploy/update_jenkins.sh

# Step 3: Run the Create_Jenkins_Stack again as normal, remembering to set the Puppet Control, Cloudformation and Scripts branches appropriately, according to the release notes.

puppet_dir=/opt/puppet

[ -z $FACTER_puppet_control_git_url ] && FACTER_puppet_control_git_url=git@gitlab.ccoe.ampaws.com.au:Confluence/puppet-control.git
[ -z $FACTER_puppet_control_git_ref ] && FACTER_puppet_control_git_ref=master

source /etc/profile.d/rvm.sh
source /etc/profile.d/amp_proxy.sh
export no_proxy=169.254.169.254
export NO_PROXY=169.254.169.254
export http_proxy=http://c2proxy.ampaws.com.au:8080
export https_proxy=http://c2proxy.ampaws.com.au:8080
export HTTP_PROXY=http://c2proxy.ampaws.com.au:8080
export HTTPS_PROXY=http://c2proxy.ampaws.com.au:8080

export ROLE=orchestration
export STAGE=startup

rm -rf $puppet_dir; mkdir $puppet_dir; chown jenkins:jenkins $puppet_dir
runuser -l jenkins -s /bin/bash -c "git clone -b $FACTER_puppet_control_git_ref $FACTER_puppet_control_git_url $puppet_dir"
runuser -l jenkins -s /bin/bash -c "cd $puppet_dir; r10k puppetfile install -v"
cd $puppet_dir && puppet apply --ordering=manifest --hiera_config=hiera.yaml --modulepath=modules manifests/update_jenkins.pp
