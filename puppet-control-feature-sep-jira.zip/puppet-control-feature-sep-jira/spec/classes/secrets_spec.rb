# THIS FILE IS CENTRALLY MANAGED BY update_rspec.rb!
# DO NOT EDIT IT HERE!

require 'spec_helper'
require 'json'

if ENV['TEST_SECRETS'] and File.exists?('hieradata/credstash.yaml')
  describe 'Secrets' do
    context 'Credstash setup' do
      it 'credstash command should exist and be executable' do
        expect(File.executable?('/usr/bin/credstash.py')).to be true
      end

      it 'crestash table should be in dynamodb' do
        expect(JSON.parse(%x{aws dynamodb list-tables \
          --region ap-southeast-2 \
          --query 'TableNames[*]'})
        ).to include 'credential-store'
      end
    end

    context 'secrets in credstash.yaml' do
      secrets = JSON.parse(%x{credstash -r ap-southeast-2 getall})
      Dir.glob('hieradata/**/*.yaml').select{|x| x =~ /credstash/}.each do |f|
        YAML.load_file(f).keys.each do |k|
          it k do
            if ! secrets.has_key?(k)
              project = %x{git remote -v}.split[1].gsub(/^git.*:/, '').gsub(/\/.*$/, '')
              g = f.gsub(/[\/\.]/, '_')
              modified_k = "#{project}_#{g}_#{k}"
              expect(secrets.has_key?(modified_k)).to be true
            else
              expect(secrets.has_key?(k)).to be true
            end
          end
        end
      end
    end
  end
end
