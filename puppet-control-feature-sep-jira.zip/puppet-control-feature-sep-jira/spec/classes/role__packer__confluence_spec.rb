# THIS FILE IS CENTRALLY MANAGED BY update_rspec.rb!
# DO NOT EDIT IT HERE!

require 'spec_helper'

describe 'tenant_role::packer::confluence' do
  {
    'confluence-pilot' => ['DEV'],
  }
  .each do |aws_account, environments|

    environments.each do |environment|

      context "aws account #{aws_account} environment #{environment}" do
        let(:environment){ environment }
        let(:facts) do
          {
            :aws_account => aws_account,
          }
        end

        it {
          is_expected.to compile.with_all_deps
          File.write(
            "catalogs/tenant_role::packer::confluence_#{aws_account}_#{environment}.json",
            PSON.pretty_generate(catalogue)
          )
        }
      end
    end
  end
end
