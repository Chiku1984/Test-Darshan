# THIS FILE IS CENTRALLY MANAGED BY update_rspec.rb!
# DO NOT EDIT IT HERE!

require 'spec_helper'
require 'nokogiri'
require 'yaml'

project = %x{git remote -v}.split[1].gsub(/^git.*:/, '').gsub(/\/.*$/, '')

cloudformation_git_url = ENV['CLOUDFORMATION_GIT_URL'] ? ENV['CLOUDFORMATION_GIT_URL'] : "git@gitlab.ccoe.ampaws.com.au:#{project}/cloudformation.git"
cloudformation_git_ref = ENV['CLOUDFORMATION_GIT_REF'] ? ENV['CLOUDFORMATION_GIT_REF'] : 'master'
cloudformation_dir     = "#{project}_cloudformation"

ccoe_cloudformation_git_url = ENV['CCOE_CLOUDFORMATION_GIT_URL'] ? ENV['CCOE_CLOUDFORMATION_GIT_URL'] : 'git@gitlab.ccoe.ampaws.com.au:CCOE/cloudformation.git'
ccoe_cloudformation_git_ref = ENV['CCOE_CLOUDFORMATION_GIT_REF'] ? ENV['CCOE_CLOUDFORMATION_GIT_REF'] : 'master'
ccoe_cloudformation_dir     = 'CCOE_cloudformation'

%x{git clone #{ccoe_cloudformation_git_url} -b #{ccoe_cloudformation_git_ref} #{ccoe_cloudformation_dir}}

# For the CCOE code bases only, cloudformation_git_url will normally equal ccoe_cloudformation_git_url.
unless cloudformation_git_url == ccoe_cloudformation_git_url
  %x{git clone #{cloudformation_git_url} -b #{cloudformation_git_ref} #{cloudformation_dir}}
end

param_validation_exceptions = ['Create_Jenkins_Stack']

describe 'role::startup::orchestration' do
  before(:each) do
    @project = %x{git remote -v}.split[1].gsub(/^git.*:/, '').gsub(/\/.*$/, '')
    @jobs = catalogue.resource_keys.select{|k,v| k == 'Jenkins::Jobs'}.map{|k,v| v}
    @cloudformation_dir      = "#{@project}_cloudformation"
    @ccoe_cloudformation_dir = 'CCOE_cloudformation'

    def content(file_name)
      catalogue.resource('file', file_name).send(:parameters)[:content]
    end

    def cf_template_file(content)
      content.match(/template-body.*\/([^\/]+\.json)/)[1]
    end
    # We usually have two cloudformations - CCOE and tenant-specific.
    # We will not allow duplicate templates, because the name conflict could one day be a problem, and
    # probably currently indicate that a tenant has forked a CCOE template.
    def cf_template_file_exists_uniquely(cf_template_file)

      unless @cloudformation_dir == @ccoe_cloudformation_dir

        # Note the use of Ruby XOR (^).
        if ! File.exist?("./#{@cloudformation_dir}/#{cf_template_file}") ^ File.exist?("#{@ccoe_cloudformation_dir}/#{cf_template_file}")
          puts "    Template file #{cf_template_file} exists in multiple cloudformation repos"
          return false
        end
      end
      return Dir.glob("./*cloudformation/#{cf_template_file}")[0]
    end

    def json_snippet(json_file, content)
      content.match(/#{json_file}(.*?)EOF/m)[1]
    end

    # WIP.
    def parameter_values(json_snippet)
      JSON.parse(json_snippet).map{|k| k['ParameterValue']}
    end

    # WIP.
    def get_jenkins_global_vars(aws_account)
      YAML.load_file("hieradata/aws/#{aws_account}.yaml")['jenkins_global_vars']
    end

    # WIP.
    def get_choice_parameters(content)
      xml_file = Nokogiri::XML.parse(content)
    end
  end

  [
    'confluence-np',
    'confluence-pilot',
    'confluence',
  ]
  .each do |aws_account|

    context "aws account #{aws_account}" do
      let(:facts) do
        {
          :aws_account => aws_account
        }
      end

      it 'All Jenkins jobs have valid XML' do
        @jobs.each do |j|
          content = content("/tmp/#{j}.xml")
          result = Nokogiri::XML(content).errors.empty?
          if ! result
            puts "    Job #{j} has invalid XML"
            puts "    #{Nokogiri::XML(content).errors}"
          end
          File.open("catalogs/jobs/xml/#{aws_account}/#{j}.xml", 'w') {|g| g.write(content)}
          expect(result).to be true
        end
      end

      it 'All XML should contain Bash Shell scripts that are valid or no scripts' do
        @jobs.each do |j|
          content = catalogue.resource('file', "/tmp/#{j}.xml").send(:parameters)[:content]
          shell_scripts = Nokogiri::XML(content).xpath('/project/builders/hudson.tasks.Shell/command').map(&:text)
          shell_scripts.each_with_index do |s,i|
            [['&lt;', '<'], ['&gt;', '>'], ['&amp;', '&'], ['&quot;', '"'], ['&apos;', "'"]].each do |k,v|
              s.gsub!(/#{k}/, v)
            end
            f = "catalogs/jobs/bash/#{aws_account}/#{j}_#{i}.sh"
            File.open(f, 'w') {|g| g.write(s)}
            result = system("bash -n #{f} > /dev/null 2>&1")
            if ! result
              puts "    Job #{j} has Bash script #{j}_#{i}.sh with syntax errors"
            end
            expect(result).to be true
          end
        end
      end

      ['variables.json', 'tags.json'].each do |json_file|
        it "All XML should contain a #{json_file} snippet that is valid JSON" do
          @jobs.each do |j|
            content = content("/tmp/#{j}.xml")
            if content.match(/cat &lt;&lt; EOF &gt; #{json_file}.*?EOF/m)
              begin
                JSON.parse(json_snippet(json_file, content))
              rescue
                puts "    Job #{j} has a JSON file #{json_file} that is invalid JSON"
              end
              expect { JSON.parse(json_snippet(json_file, content)) }.to_not raise_error
            end
          end
        end
      end

      # 'unless' is a temporary workaroud until all tenants are ready.
      unless ['ISAM', 'SOC', 'Confluence', 'AEM', 'Bett3r', 'CSDS', 'EDI', 'WSO2', 'INS'].include?(project)

        it 'CF template mentioned in Jenkins jobs should exist in a Cloudformation repo' do
          @jobs.each do |j|
            content = content("/tmp/#{j}.xml")
            if content.match(/cat &lt;&lt; EOF &gt; variables.json.*?EOF/m) and content.match(/template-body.*json/)

              cf_template_file = cf_template_file(content)
              next if Dir.glob("*cloudformation/#{cf_template_file}").empty?

              expect(cf_template_file_exists_uniquely(cf_template_file)).to_not be false
            end
          end
        end

        it 'All variables.json files should match their CF templates' do
          (@jobs - param_validation_exceptions).each do |j|
            content = content("/tmp/#{j}.xml")
            if content.match(/cat &lt;&lt; EOF &gt; variables.json.*?EOF/m) and content.match(/template-body.*json/)

              cf_template_file = cf_template_file(content)
              next if Dir.glob("*cloudformation/#{cf_template_file}").empty?

              cf_template_keys = JSON.parse(File.read(cf_template_file_exists_uniquely(cf_template_file)))['Parameters'].keys.sort

              json_snippet_keys = []
              JSON.parse(json_snippet('variables.json', content)).each do |el|
                json_snippet_keys << el['ParameterKey']
              end
              json_snippet_keys.sort!

              # Work-around until CC-1821 is implemented.
              unless cf_template_keys.include?('KeyName')
                unless json_snippet_keys == cf_template_keys
                  puts "    variables.json keys in job #{j}: #{json_snippet_keys}"
                  puts "    CF template param keys in #{cf_template_file}: #{cf_template_keys}"
                end
                expect(json_snippet_keys).to match_array cf_template_keys
              end
            end
          end
        end
      end

      it 'All variables.json snippets should contain keys sorted alphabetically' do
        @jobs.each do |j|
          content = content("/tmp/#{j}.xml")
          if content.match(/cat &lt;&lt; EOF &gt; variables.jsonEOF/m)
            keys = JSON.parse(json_snippet('variables.json', content)).map{|k| k['ParameterKey']}
            expect(keys).to eql keys.sort
          end
        end
      end

      it 'should write out a compiled catalog' do
        is_expected.to compile.with_all_deps
        File.write(
          "catalogs/role__startup__orchestration_#{aws_account}.json",
          PSON.pretty_generate(catalogue)
        )
      end
    end
  end

  context 'some RPMs are specified' do
    let(:facts) do
      {
        :aws_account => 'confluence-pilot',
      }
    end
    let(:params) do
      {
        'rpm_packages' => {'mypackage' => {'ensure' => 'installed'}},
      }
    end

    it 'should contain a package mypackage' do
      is_expected.to contain_package('mypackage').with({
        'ensure' => 'installed',
      })
    end
  end
end
