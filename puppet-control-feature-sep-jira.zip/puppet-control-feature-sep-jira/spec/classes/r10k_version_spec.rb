# THIS FILE IS CENTRALLY MANAGED BY update_rspec.rb!
# DO NOT EDIT IT HERE!

require 'spec_helper'

# Our Puppetfile is really just Ruby code that calls a 'mod' method that is normally defined in r10k.
# Here we redefine the 'mod' method in this file to create the tests so that we can simply eval
# the Puppetfile content to create the Rspec tests.

def mod(mod, opts)
  if opts.has_key?(:ref) and opts[:ref] != 'master'
    # No need to run this slow test if g10k checked it out less than 10 minutes ago.
    if Time.now.to_i - File.mtime("modules/#{mod}").to_i > 10*60*60
      it "Puppetfile mod #{mod} should have a tag #{opts[:ref]}" do
        expect(%x{git ls-remote --refs #{opts[:git]} 2>/dev/null}).to match /#{opts[:ref]}/
      end
    end
  end
end

describe 'r10k checks and Git tags' do
  it 'Gemfile.lock must mention r10k' do
    return_val = false
    %x{git blame Gemfile.lock}.split("\n").delete_if{|x| x.match(/Not Committed Yet/)}.each do |l|
      if l.match(/r10k/)
        return_val = true
      end
    end
    expect(return_val).to be false
  end

  it 'Gemfile must mention an r10k version' do
    expect(File.read('Gemfile')).to match /r10k.*\d/
  end

  puppetfile = File.read('Puppetfile')
  eval(puppetfile)

  %w{amp ant autofs aws concat customlib dirtree dynatrace epel fstab
    java jenkins jenkins_config maven mounts ntp packer postfix python
    role rsyslog ssh stdlib stunnel sys users wget}
  .
  each do |mod|

    it "Puppetfile must contain #{mod}" do
      expect(puppetfile).to match /mod '#{mod}'/
    end
  end

  # Also check for the Git tags mentioned on Create_Jenkins_Stack for Cloudformation and Scripts.
  cloudformation_git_ref = String.new
  scripts_git_ref = String.new
  Dir.glob('hieradata/**/*.yaml').each do |f|
    yaml = YAML.load_file(f)
    begin
      cloudformation_git_ref = yaml['jenkins_jobs']['Create_Jenkins_Stack']['config']['cloudformation_git_ref']
      scripts_git_ref        = yaml['jenkins_jobs']['Create_Jenkins_Stack']['config']['scripts_git_ref']
    rescue
    end
  end

  it 'Create_Jenkins_Stack cloudformation_git_ref must exist' do
    expect(%x{git ls-remote --refs git@gitlab.ccoe.ampaws.com.au:CCOE/cloudformation.git 2>/dev/null}).to match /#{cloudformation_git_ref}/
  end

  it 'Create_Jenkins_Stack scripts_git_ref must exist' do
    expect(%x{git ls-remote --refs git@gitlab.ccoe.ampaws.com.au:CCOE/scripts.git 2>/dev/null}).to match /#{scripts_git_ref}/
  end
end
