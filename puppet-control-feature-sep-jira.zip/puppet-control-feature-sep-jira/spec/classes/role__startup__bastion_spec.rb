# THIS FILE IS CENTRALLY MANAGED BY update_rspec.rb!
# DO NOT EDIT IT HERE!

require 'spec_helper'

describe 'role::startup::bastion' do
  context 'aws account confluence' do
    let(:facts) do
      {
        :aws_account => 'confluence',
      }
    end

    it 'should not have user keys' do
      is_expected.to have_ssh_authorized_key_resource_count(0)
    end

    it 'should contain an exec with AD password interpolated correctly' do
      expected_ad_svc_user_pass =
        YAML.load_file('hieradata/credstash.yaml')['ad::svc_user_pass']
      expected_ad_svc_user =
        YAML.load_file('hieradata/common.yaml')['ad::svc_user_id']
      is_expected.
        to contain_exec("net ads leave -U '#{expected_ad_svc_user}%#{expected_ad_svc_user_pass}'")
    end

    it 'should write out a compiled catalog' do
      File.write(
        'catalogs/role__startup__bastion_confluence.json',
        PSON.pretty_generate(catalogue)
      )
    end
  end
end
