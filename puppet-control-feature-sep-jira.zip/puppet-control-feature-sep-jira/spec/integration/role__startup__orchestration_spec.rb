# THIS FILE IS CENTRALLY MANAGED BY update_rspec.rb!
# DO NOT EDIT IT HERE!

require 'serverspec'

set :backend, :exec

describe user('jenkins') do
  it { is_expected.to exist }
end

describe process('java') do
  its(:user)  { is_expected.to eq 'jenkins' }
  its(:count) { is_expected.to eq 1 }
  its(:args)  { is_expected.to match /-jar \/usr\/lib\/jenkins\/jenkins\.war/ }
  it { is_expected.to be_running }
end

# Check the Puppet log for errors.
describe file('/root/orchestration_startup.log') do
  its(:content) { is_expected.to_not match /error/i }
end

# SSH / git clone access to Gitlab.
describe command("runuser -l jenkins -s /bin/bash -c 'ssh git@gitlab.ccoe.ampaws.com.au'") do
  its(:stdout) { is_expected.to match /Welcome to GitLab/ }
end

describe command("runuser -l jenkins -s /bin/bash -c 'java -jar jenkins-cli.jar -i ~/.ssh/id_rsa -s https://localhost:8443/ -noCertificateCheck list-jobs'") do
  its(:stdout) { is_expected.to match /Create_Jenkins_Stack/ }
end

describe command("runuser -l jenkins -s /bin/bash -c 'java -jar jenkins-cli.jar -i ~/.ssh/id_rsa -s https://localhost:8443/ -noCertificateCheck list-plugins'") do
  its(:stdout) { is_expected.to match /Git plugin/ }
end

describe command("runuser -l jenkins -s /bin/bash -c 'java -jar jenkins-cli.jar -i ~/.ssh/id_rsa -s https://localhost:8443/ -noCertificateCheck who-am-i'") do
  its(:stdout) { is_expected.to match /Authenticated as:/ }
  its(:stdout) { is_expected.to match /Domain Users/ }
end

describe x509_certificate('/var/lib/jenkins/ssl/jenkins.ampaws.com.au.certchain.pem') do
  its(:validity_in_days) { is_expected.to be >= 30 }
end

describe x509_private_key('/var/lib/jenkins/ssl/jenkins.ampaws.com.au.key') do
  it { is_expected.to have_matching_certificate('/var/lib/jenkins/ssl/jenkins.ampaws.com.au.certchain.pem') }
end
