#!/usr/bin/env rspec
#
require 'serverspec'
require 'json'

$stdout.sync = true

set :backend, :exec
set :env,
  :GEM_PATH     => ENV['GEM_PATH'],
  :RUBY_VERSION => ENV['RUBY_VERSION'],
  :FACTERLIB    => '/opt/puppet/modules/customlib/lib/facter'

require_relative './components'
require_relative './serverspec'

properties = {
  'confluence' => {
    'hosted_domain'            => 'confluence.ampaws.com.au',
    'external_domainname'      => 'teamtools.amp.com.au',
    'confluence_jvm_min_size'  => '4096',
    'confluence_jvm_max_size'  => '8192',
    'confluence_instance_type' => 'c4.2xlarge',
    'jira_jvm_min_size'        => '4096',
    'jira_jvm_max_size'        => '4096',
    'jira_instance_type'       => 'c4.xlarge',
  },
  'confluence-np' => {
    'hosted_domain'            => 'confluence-np.ampaws.com.au',
    'external_domainname'      => 'teamtools.ccoe-np.ampaws.com.au',
    'confluence_jvm_min_size'  => '2048',
    'confluence_jvm_max_size'  => '2048',
    'confluence_instance_type' => 'c4.xlarge',
    'jira_jvm_min_size'        => '2048',
    'jira_jvm_max_size'        => '2048',
    'jira_instance_type'       => 'c4.xlarge',
  },
  'confluence-pilot' => {
    'hosted_domain'            => 'confluence-pilot.ampaws.com.au',
    'external_domainname'      => 'teamtools.ccoe-pilot.ampaws.com.au',
    'confluence_jvm_min_size'  => '2048',
    'confluence_jvm_max_size'  => '2048',
    'confluence_instance_type' => 'c4.large',
    'jira_jvm_min_size'        => '2048',
    'jira_jvm_max_size'        => '2048',
    'jira_instance_type'       => 'c4.large',
    'dynatrace'                => false,
  },
}[host_inventory['facter']['aws_account']]

#
# we need the dynamic variables pumped into puppet, I don't like this but is there another way
#
dynamic = YAML.load_file('/opt/puppet/hieradata/dynamic.yaml')

#
# Host tests to run
#
context "host level unit tests" do

  tenant_role = host_inventory['facter']['tenant_role']

  describe "instance type" do
    let(:instance_type) { host_inventory['ec2']['instance-type'] }
    it { expect(instance_type).to eq properties["#{tenant_role}_instance_type"] }
  end

  it_should_behave_like "teamtools #{tenant_role} application",
    db_host: dynamic["tenant_role::startup::#{tenant_role}::db_hostname"],
    cluster_security_group: dynamic["tenant_role::startup::#{tenant_role}::cluster_security_group"],
    hosted_domain: properties['hosted_domain'],
    external_domainname: properties['external_domainname'],
    jvm_min_size: properties["#{tenant_role}_jvm_min_size"],
    jvm_max_size: properties["#{tenant_role}_jvm_max_size"]

  it_should_behave_like 'gluster client',
    hosted_domain: properties['hosted_domain']

  if properties.fetch('dynatrace', true)
    it_should_behave_like 'dynatrace agent'
  end

  it_should_behave_like 'taskrunner agent'

  it_should_behave_like 'td-agent agent'

  it_should_behave_like 'Linux RHEL7 SOE',
    image_name_regex: /\Aencrypted-atlassiandc-\d{12}\Z/

end
