require 'serverspec'

# Monkey patch as AMP security policy does not all netcat to be on servers
module Serverspec::Type::AMP

  module Redhat
    module V7
      module Host

        def check_is_reachable(host, port, proto, timeout)
          if port.nil?
            "ping -w #{escape(timeout)} -c 2 -n #{escape(host)}"
          else
            "timeout #{escape(timeout)} bash -c 'cat < /dev/null > /dev/#{escape(proto)}/#{escape(host)}/#{escape(port)}'"
          end
        end

      end
    end
  end

end


unless package('nmap-ncat').installed?

  # No namp/netcat package, let's use a clever bash trick to test tcp ports

  Specinfra::Command::Redhat::V7::Host.class_eval do
    class << self
      prepend Serverspec::Type::AMP::Redhat::V7::Host
    end
  end

end
