module ServerspecAMPTypes
  VERSION = "0.0.1"
end
