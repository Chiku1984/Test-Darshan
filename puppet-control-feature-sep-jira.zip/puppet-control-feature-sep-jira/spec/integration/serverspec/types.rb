require_relative './types/host.rb'
require_relative './types/http_get.rb'
require_relative './types/loadbalancer_certificate.rb'
require_relative './types/processes.rb'
