#
# DynaTrace Tests
#
shared_examples 'dynatrace agent' do

  describe group('dtuser') do
    it { is_expected.to exist }
  end

  describe user('dtuser') do
    it { is_expected.to exist }
    it { should belong_to_primary_group 'dtuser' }
    its(:encrypted_password) { should match(/^.{0,2}$/) } # no password
  end

  describe service('oneagent') do
    it { should be_enabled }
    it { should be_running }
  end

  describe process('oneagentwatchdog') do
    its(:user)  { is_expected.to eq 'root' }
    its(:count) { is_expected.to eq 1 }
    it { is_expected.to be_running }
  end

end
