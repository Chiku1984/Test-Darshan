require_relative './aws'

#
# Common tests for RHEL7 SOE
#
shared_examples 'Linux RHEL7 SOE' do |image_name_regex: nil,
                                      test_image_encrypted: true|

  # why is this not being parsed as array?
  sg_ids = host_inventory['ec2']['network']['interfaces']['macs'].map {|k,v| v['security-group-ids'].lines.map(&:chomp) }.flatten.uniq

  # OS release
  describe "operating system version" do
    let(:family)  { os[:family] }
    let(:release) { os[:release] }
    it { expect(family).to eq 'redhat' }
    it { expect(release).to match /^7\.[0-9]+$/ }
  end

  # /tmp directory permissions/owner
  describe file('/tmp') do
    it { should be_directory }
    it { should be_owned_by 'root' }
    it { should be_grouped_into 'root' }
    it { should be_mode 1777 }
  end

  # Splunk agent
  context "Splunk Forwarder agent" do

    describe package('splunkforwarder') do
      it { should be_installed }
    end

    describe service('splunk') do
      it { should be_enabled }
      it { should be_running }
    end

    describe process('splunkd') do
      its(:user)  { is_expected.to eq 'splunk' }
      its(:group) { is_expected.to eq 'splunk' }
      its(:count) { should be >= 2 }
      it { is_expected.to be_running }
    end

  end

  # IBM BES Client
  context "IBM BES Client agent" do

    describe package('BESAgent') do
      it { should be_installed }
    end

    describe service('besclient') do
      it { should be_enabled }
      it { should be_running }
    end

    describe process('BESClient') do
      its(:user)  { is_expected.to eq 'root' }
      its(:group) { is_expected.to eq 'root' }
      its(:count) { should be >= 1 }
      it { is_expected.to be_running }
    end

  end

  # Qualys agent
  context "Qualys Cloud agent" do

    describe package('qualys-cloud-agent') do
      it { should be_installed }
    end

    describe service('qualys-cloud-agent') do
      it { should be_enabled }
      it { should be_running }
    end

    describe process('qualys-cloud-agent') do
      its(:user)  { is_expected.to eq 'root' }
      its(:group) { is_expected.to eq 'root' }
      its(:count) { is_expected.to eq 1 }
      it { is_expected.to be_running }
    end

  end

  # Trend Micro agent
  context "Trend Micro agent" do

    describe package('ds_agent') do
      it { should be_installed }
    end

    describe file('/opt/ds_agent/ds_agent') do
      it { should be_file }
      it { should be_owned_by 'root' }
      it { should be_grouped_into 'root' }
      it { should be_mode 700 }
    end

    describe service('ds_agent') do
      it { should be_enabled }
      it { should be_running }
    end

    describe process('ds_agent') do
      its(:user)  { is_expected.to eq 'root' }
      its(:group) { is_expected.to eq 'root' }
      its(:count) { should be >= 1 }
      it { is_expected.to be_running }
    end

    describe ec2_security_groups(sg_ids) do
      it { should be_port_accessible_from('172.16.4.14', 'tcp:4118') }
    end

  end

  # Infosys SSH access
  context "Infosys SSH Inbound" do

    describe ec2_security_groups(sg_ids) do
      it { should be_port_accessible_from('172.16.3.185', 'tcp:22') }
      it { should be_port_accessible_from('172.16.4.196', 'tcp:22') }
    end

  end

  # Cloudwatch metrics cron
  describe cron do
    it { should have_entry('0 * * * * bash /opt/aws/cloudwatch_put_service_status.sh').with_user('root') }
  end

  filesystems = {
    '/'        => '/dev/xvda2',
    '/home'    => '/dev/mapper/vgvdc-home' ,
    '/tmp'     => '/dev/mapper/vgvdc-tmp',
    '/var'     => '/dev/mapper/vgvdc-var',
    '/var/log' => '/dev/mapper/vgvdc-var_log',
    '/opt'     => '/dev/mapper/vgvdc-opt',
  }

  xfs_opts = {
    :rw       => true,
    :relatime => true,
    :seclabel => true,
    :attr2    => true,
    :inode64  => true,
  }

  filesystems.each do |mount,device|
    describe file(mount) do
      it { should be_mounted.with(:device => device, :type => 'xfs', :options => xfs_opts) }
    end
  end

  describe file('/tmp') do
    it { should be_mounted.with(:options => {:nosuid => true, :nodev => true}) }
  end

  # test proxy connection
  describe host('c2proxy.ampaws.com.au') do
    it { should be_reachable.with( :port => 8080, :proto => 'tcp', :timeout => 1 ) }
  end

  context "ami has encrypted volumes" do

    describe ec2_image(host_inventory['ec2']['ami-id']) do
      if image_name_regex
        its(:image_name) { should match image_name_regex }
      end
      unless test_image_encrypted == false
        its(:root_volume) { should be_encrypted }
      end
    end

  end

  # No ssh access from 0.0.0.0/0 for Prod/Non-Prod
  if host_inventory['facter']['aws_account'] !~ /\-pilot$/
    context "has restricted security groups" do

      describe ec2_security_groups(sg_ids) do
        it { should_not be_port_accessible_from('0.0.0.0/0', 'tcp:22') }
      end

      describe ec2_security_groups(sg_ids) do
        it { should_not be_accessible_from('0.0.0.0/0') }
      end

    end
  end

end
