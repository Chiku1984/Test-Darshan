#
# Gluster Tests
#
shared_examples 'gluster client' do |hosted_domain:|

  mica_ca_subject = /#{Regexp.escape('/C=AU/O=AMP - Internal Services/OU=Infosec/CN=MICA Infosec Issuing CA - ')}(Prod|NonProd)$/

  describe package('glusterfs-fuse') do
    it { should be_installed }
  end

  context 'Enforce Gluster Encryption' do

    describe file('/var/lib/glusterd/secure-access') do
      it { should be_file }
      it { should be_mode 600 }
      it { should be_owned_by 'root' }
      it { should be_grouped_into 'root' }
      its(:size) { should = 0 }
    end

  end

  context 'MICA Root CA' do

    # chain file - not sure how to validate both AMP Root and MICA Root certs
    # match 2 base64 encoded certificates in the pem file
    pem_chain_regex = /\A(
      \s*^#{Regexp.escape('-----BEGIN CERTIFICATE-----')}$
      (?:\s*^[A-Za-z0-9\+\/]{64}$)+
      (?:\s*^(?:[A-Za-z0-9\+\/]{4})+(?:[A-Za-z0-9\+\/]{2}==|[A-Za-z0-9\+\/]{3}=)?$)
      \s*^#{Regexp.escape('-----END CERTIFICATE-----')}$
    ){2}\Z/x

    describe file('/etc/ssl/glusterfs.ca') do
      it { should be_file }
      it { should be_mode 600 }
      it { should be_owned_by 'root' }
      it { should be_grouped_into 'root' }
      its(:content) { should match pem_chain_regex }
    end

    describe x509_certificate('/etc/ssl/glusterfs.ca') do
      it { should be_certificate }
      it { should be_valid }
      its(:subject) { should eq '/CN=AMP Root CA' } # mica_ca_subject }
      its(:validity_in_days) { should be >= 30 }
    end

  end

  context 'Gluster Node Private Key' do

    describe file('/etc/ssl/glusterfs.key') do
      it { should be_file }
      it { should be_mode 600 }
      it { should be_owned_by 'root' }
      it { should be_grouped_into 'root' }
    end

    describe x509_private_key('/etc/ssl/glusterfs.key') do
      it { should_not be_encrypted }
      it { should be_valid }
      it { should have_matching_certificate('/etc/ssl/glusterfs.pem') }
    end

  end

  context 'Gluster Node Certificate' do

    describe file('/etc/ssl/glusterfs.pem') do
      it { should be_file }
      it { should be_mode 600 }
      it { should be_owned_by 'root' }
      it { should be_grouped_into 'root' }
    end

    # parent_subject = '/C=AU/O=AMP Internal Services - projects/OU=Cost_Centre:TW033/CN='

    describe x509_certificate('/etc/ssl/glusterfs.pem') do
      it { should be_certificate }
      it { should be_valid }
      its(:issuer) { should match mica_ca_subject }
      its(:subject) { should match /\/CN=[^.]+\.#{Regexp.escape(hosted_domain)}(\/.*)?/ } # not easy to determine - UAT different
      # its(:subject) { should match /^#{Regexp.escape(parent_subject)}[^.]+\.#{Regexp.escape(hosted_domain)}$/ }
      its(:validity_in_days) { should be >= 30 }
    end

  end

end
