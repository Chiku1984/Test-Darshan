require_relative './teamtools_application/common.rb'
require_relative './teamtools_application/confluence.rb'
require_relative './teamtools_application/jira.rb'
