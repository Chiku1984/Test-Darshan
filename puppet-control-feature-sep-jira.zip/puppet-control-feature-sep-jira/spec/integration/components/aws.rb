require_relative './aws/autoscaling.rb'
require_relative './aws/ec2.rb'

# require 'rspec/expectations'

RSpec::Matchers.define :include_hash_matching do |expected|
  match do |array_of_hashes|
    array_of_hashes.any? { |element| element.select { |key| expected.keys.include? key } == expected }
  end
end

# module AWSInstanceMetaData
#
#   class << self
#
#     attr_accessor :image_id
#     attr_accessor :instance_id
#     attr_accessor :region
#     attr_accessor :account
#
#   end
#
#   # need to determine what the ec2 instance id is
#   sts = Aws::STS::Client.new
#   sts_identity = sts.get_caller_identity
#   self.instance_id = sts_identity.user_id.split(':', 2).last
#   self.account = sts_identity.account
#
#   # retrive the ec2 instance details
#   ec2 = Aws::EC2::Client.new
#   ec2_instance_data = ec2.describe_instances({instance_ids: [self.instance_id] }).reservations[0].instances[0]
#
#   self.image_id = ec2_instance_data.image_id
#   self.region = ec2_instance_data.placement.availability_zone[0...-1]
#
# end
