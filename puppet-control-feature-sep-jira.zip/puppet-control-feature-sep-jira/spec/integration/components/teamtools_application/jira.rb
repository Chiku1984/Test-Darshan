#
# Common tests for Teamtools jira application
#
shared_examples 'teamtools jira application' do |hosted_domain:,
                                                 external_domainname:,
                                                 db_host:,
                                                 cluster_security_group:,
                                                 jvm_min_size:,
                                                 jvm_max_size:|

  it_should_behave_like 'teamtools application',
    application: 'jira',
    user: 'jira',
    group: 'jira',
    service: 'jira',
    process_arg: '-Dcatalina.base=/opt/jira/atlassian-jira-software-7.4.2-standalone',
    listening: [ '0.0.0.0:9443', '0.0.0.0:5443' ],
    loadbalancer_ports: [ 443, 5443 ],
    db_host: db_host,
    cluster_security_group: cluster_security_group,
    hosted_domain: hosted_domain,
    external_domainname: external_domainname,
    jvm_min_size: jvm_min_size,
    jvm_max_size: jvm_max_size,
    jvm_opts: []

    jira_content = '<meta name="application-name" content="JIRA" data-name="jira" data-version="7.4.2"><meta name="ajs-dev-mode" content="false">'

    describe http_get('https://localhost:9443/jira/', timeout_sec=2, bypass_ssl_verify=true) do
      it { should_not be_timed_out }
      it { should_not be_redirected }
      its(:body) { should match /#{Regexp.escape(jira_content)}/ }
    end

end
