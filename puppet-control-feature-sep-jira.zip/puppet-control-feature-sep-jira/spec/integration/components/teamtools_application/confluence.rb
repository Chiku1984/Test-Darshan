#
# Common tests for Teamtools Confluence application
#
shared_examples 'teamtools confluence application' do |hosted_domain:,
                                                       external_domainname:,
                                                       db_host:,
                                                       cluster_security_group:,
                                                       jvm_min_size:,
                                                       jvm_max_size:|

  aws_region = host_inventory['ec2']['placement']['availability-zone'][0...-1]
  ip_address_dash = host_inventory['ec2']['local-ipv4'].tr(".", "-")

  it_should_behave_like 'teamtools application',
    application: 'confluence',
    user: 'confluence',
    group: 'confluence',
    service: 'confluence',
    process_arg: '-Dcatalina.base=/opt/confluence',
    listening: [ '0.0.0.0:9443', '0.0.0.0:5443', '127.0.0.1:8090' ],
    loadbalancer_ports: [ 443, 5443 ],
    db_host: db_host,
    cluster_security_group: cluster_security_group,
    hosted_domain: hosted_domain,
    external_domainname: external_domainname,
    jvm_min_size: jvm_min_size,
    jvm_max_size: jvm_max_size,
    jvm_opts: [ '-XX:ReservedCodeCacheSize=384m', '-Dconfluence.document.conversion.fontpath=/usr/share/fonts/msttcore' ]

  describe cron do
    it { should have_entry("0 1 * * * sleep $[RANDOM\\%120]m ; rsync -rlpt /data/confluence/ /shared/confluence/node-copy-6.3.2/ip-#{ip_address_dash}/home --delete").with_user('root') }
  end

  context "query cluster members" do
    describe command("aws ec2 describe-instances --region #{aws_region} --filters Name=instance.group-name,Values=#{cluster_security_group} --output text --query Reservations[].Instances[].InstanceId") do
      its(:exit_status) { should eq 0 }
      its(:stdout) { is_expected.to match /\A(i-[0-9a-f]{17}(\Z|\t))+/ }
    end
  end

  confluence_redirect_uri = '/confluence/login.action?os_destination=%2Findex.action&permissionViolation=true'

  describe http_get('https://localhost:9443/confluence/', timeout_sec=2, bypass_ssl_verify=true) do
    it { should_not be_timed_out }
    it { should be_redirected }
    it { should be_redirected_to confluence_redirect_uri }
  end

  confluence_content = '<meta name="decorator" content="none"/><script src="/confluence/s/'
  office365_redirect = 'window.location.assign("https://login.microsoftonline.com/'

  describe http_get("https://localhost:9443/#{confluence_redirect_uri}", timeout_sec=6, bypass_ssl_verify=true) do
    it { should_not be_timed_out }
    it { should_not be_redirected }
    its(:headers) { should include('x-confluence-request-time' => /\d+/) }
    its(:body) { should match /#{Regexp.escape(confluence_content)}/ }
    its(:body) { should match /#{Regexp.escape(office365_redirect)}/ }
  end

  describe file('/usr/share/fonts/msttcore') do
    it { should be_directory }
    it { should be_owned_by 'confluence' }
    it { should be_grouped_into 'confluence' }
  end

end
