#!/bin/bash -e
#
# Some what simulate what Jenkins does

sudo -u jenkins bash --login << EOF

export GEM_HOME=\$HOME/.gems
export PATH=\$GEM_HOME/bin:/usr/local/rvm/gems/ruby-2.1.4/bin:\$PATH
source /etc/profile.d/rvm.sh

TMPDIR=\$(mktemp -dq /tmp/puppet-control.XXXXXXX)
cp /opt/puppet/Gemfile /opt/puppet/Gemfile.lock \$TMPDIR
PUPPET_GEM_VERSION="5.3.3" bundle install --gemfile \$TMPDIR/Gemfile --system --without system_tests
rm -rf \$TMPDIR

EOF
