#!/usr/bin/env bash
set -x

# testing only - move to puppet

cat > /etc/yum.repos.d/Gluster.repo << EOF
[gluster38]
name=Gluster 3.8
baseurl=http://mirror.centos.org/centos/7/storage/\$basearch/gluster-3.8/
gpgcheck=false
enabled=1
EOF

yum install epel-release -y
yum install rpcbind glusterfs-server -y
yum install bind-utils -y

# Cache DynaTrace Installers for Non-Prod and Prod
wget -O /root/Dynatrace-OneAgent-Linux-UAT.sh https://rqy29932.live.dynatrace.com/installer/oneagent/unix/latest/1TmlhMxZTakFl9FK
wget -O /root/Dynatrace-OneAgent-Linux-PRD.sh https://fdm19711.live.dynatrace.com/installer/oneagent/unix/latest/hAH3H2PoUVq7UiPE
chmod +x /root/Dynatrace-OneAgent-Linux-PRD.sh /root/Dynatrace-OneAgent-Linux-UAT.sh

# task runner - should be in Puppet
mkdir /opt/taskrunner
wget -O /opt/taskrunner/rds-combined-ca-bundle.pem https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem
aws s3 cp s3://amp-confluence-pilot/bake/taskrunner/TaskRunner-1.0.jar /opt/taskrunner/TaskRunner-1.0.jar
aws s3 cp s3://amp-confluence-pilot/bake/taskrunner/mysql-connector-java-bin.jar /opt/taskrunner/mysql-connector-java-bin.jar
chmod 600 /opt/taskrunner/rds-combined-ca-bundle.pem
chown -R taskrunner:taskrunner /opt/taskrunner

# aws tools for ruby - used to puppet fact to query security group members
gem install aws-sdk

# fix for ipv6
mkdir /etc/systemd/system/rpcbind.socket.d/
mv /tmp/files/no-ipv6.conf /etc/systemd/system/rpcbind.socket.d/
chmod 755 /etc/systemd/system/rpcbind.socket.d
chmod 0644 /etc/systemd/system/rpcbind.socket.d/no-ipv6.conf
chown -R root:root /etc/systemd/system/rpcbind.socket.d
