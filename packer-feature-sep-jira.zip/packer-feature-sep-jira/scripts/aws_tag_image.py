#!/usr/bin/env python
import boto
import boto.ec2
import argparse
import sys

tags = {}

def get_args():
  parser = argparse.ArgumentParser()
  parser.add_argument('--region', action='store', required=False, metavar='aws_region', dest='region', default='ap-southeast-2', help='Amazon AWS region name')
  parser.add_argument('ami_id', action='store', help='AWS EC2 AMI Id')
  parser.add_argument('tag_name', action='store', help='Specify the tag name')
  parser.add_argument('tag_value', action='store', help='Specify the tag value')
  return parser.parse_args()

def get_ec2_connection(aws_region):
  return boto.ec2.connect_to_region(aws_region)

def get_ec2_image_tags(region, ami_id):
  global tags
  conn = get_ec2_connection(region)
  for tag in [image.tags for image in conn.get_all_images(ami_id)]:
    for name, value in tag.items(): 
      print "Detected Tag name: " + name + " , Tag value: " + value
      tags[name] = value
      if 'ami-' in value:
        get_ec2_image_tags(region, value)

def tag_ec2_image(ami, tags):
  conn = get_ec2_connection(ami['region'])
  for name, value in tags.items():
    [image.add_tag(name, value) for image in conn.get_all_images(ami['ami_id'])]

def print_ec2_image_tags(**ami):
  conn = get_ec2_connection(ami['region'])
  sys.stdout.write("Tags added:\n")
  for k, v in (tag for image in conn.get_all_images(ami['ami_id']) for tag in image.tags.items()):
    sys.stdout.write("- %s: %s\n" %(k, v))
  sys.stdout.flush()

def main():
  args = get_args()
  global tags

  tags[args.tag_name] = args.tag_value
  try:
    get_ec2_image_tags(args.region, args.tag_value)
    tag_ec2_image(vars(args), tags)
    print_ec2_image_tags(**vars(args))
  except KeyboardInterrupt:
    sys.exit("User aborted script!")

if __name__ == '__main__':
  main()
