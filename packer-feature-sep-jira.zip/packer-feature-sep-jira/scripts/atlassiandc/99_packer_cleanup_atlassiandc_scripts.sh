#!/bin/bash
set -x

sudo -E sh -c 'cat << EOF >> /etc/rc.local

for i in /home/ec2-user/*atlassiandc*; do
  [ -f "\$i" ] && rm -f \$i || rm -rf \$i
done
EOF'
