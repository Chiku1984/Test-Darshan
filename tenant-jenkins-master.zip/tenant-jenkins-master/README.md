# Testing Job-Dsl

```
# Linux/Mac
./gradlew test

# Windows
.\gradlew.bat test
```